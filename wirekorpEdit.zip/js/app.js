document.addEventListener("DOMContentLoaded", () => {
  const app = document.getElementById("app");

  // Header with Corrected Links
  const header = `
        <header>
                <h1>WireKorp LLC</h1>
                <nav>
                    <ul>
                        <li><a href="#about-title">About Us</a></li>  <!-- Corrected Link to About Us Title -->
                        <li><a href="#first-service">Services</a></li> <!-- Corrected Link to First Service -->
                        <li><a href="#customer-feedback">Customer Feedback</a></li>  <!-- New Link -->
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </nav>
        </header>
    `;

  // Hero Section
  const hero = `
        <section id="home" class="hero">
            <h2>Reliable Underground Utility Solutions</h2>
            <p>Providing top-quality underground utility services with precision and expertise.</p>
            <a href="#contact" class="cta-button">Get a Quote</a>
        </section>
    `;

  // About Us Section with ID for Accurate Linking
  const aboutUs = `
        <section id="about">
            <h2 id="about-title" class="section-title">About Us</h2>  <!-- Added ID for Correct Linking -->
            <p class="about-text">
                <strong>WireKorp LLC</strong> is a <strong>trusted underground utilities company based in Georgia</strong>, proudly serving
                clients Nationwide. Our expertise extends across multiple industries, including
                <strong>Telecommunications, Gas, Water, and Fiber Optic Infrastructure.</strong>
            </p>
            <p class="about-text">
                With a team of <strong>highly skilled professionals</strong> and <strong>state-of-the-art equipment</strong>,
                we specialize in <strong>Underground Installation, Excavation, Lot Clearing, Mapping, Fiber Splicing, and more.</strong>
                Our mission is to deliver <strong>Safe, Efficient, and High-quality solutions</strong> that meet
                the growing demands of modern infrastructure.
            </p>
            <p class="about-text">
                Whether you're a <strong>residential developer, commercial contractor, or municipal planner</strong>,
                WireKorp provides <strong>customized solutions</strong> to <strong>streamline your projects, reduce costs,
                and ensure long-term reliability.</strong>
            </p>
        </section>
    `;

  // Featured Services Section with First Service ID for Accurate Linking
  const featuredServices = `
        <section id="featured-services">
            <h2 class="section-title">Services</h2>

            <div class="service-card" id="first-service">  <!-- Added ID for First Service -->
                <img src="img/excavation.jpeg" alt="Excavation">
                <div class="service-text">
                    <h3>Pipe Installation</h3>
                    <p class="large-text">Precision excavation services for underground utility installation, ensuring safety and efficiency.
                       Our experienced team handles trenching, directional drilling, and site preparation for large-scale projects.</p>
                </div>
            </div>

            <div class="service-card">
                <div class="service-text">
                    <h3>Fiber Optics</h3>
                    <p class="large-text">We specialize in fiber optic installation and splicing, providing businesses with high-speed,
                        reliable network infrastructure. Our technicians ensure precise alignment and optimal performance for seamless connectivity.</p>
                </div>
                <img src="img/fiber_optic.jpeg" alt="Fiber Optics">
            </div>

            <div class="service-card">
                <img src="img/pond.jpeg" alt="Pond">
                <div class="service-text">
                    <h3>Ponds</h3>
                    <p class="large-text">We design and build custom ponds for residential and commercial landscapes.
                        Our expertise includes excavation, water retention, and ecosystem-friendly installations to enhance the natural surroundings.</p>
                </div>
            </div>

            <!-- Pond Showcase Section -->
            <section id="pond-showcase">
                <h2 class="section-title">Pond Showcase</h2>
                <div class="video-container">
                    <video controls>
                        <source src="img/pond.mp4" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <video controls>
                        <source src="img/vid2.mp4" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <video controls>
                        <source src="img/vid3.mp4" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
            </section>

            <div class="service-card">
                <div class="service-text">
                    <h3>Mapping</h3>
                    <p class="large-text">We offer advanced mapping and redline production to assist in utility planning and
                        asset management. Our digital mapping ensures accuracy in project execution and long-term site maintenance.</p>
                </div>
                <img src="img/mapping.jpeg" alt="Mapping">
            </div>

            <div class="service-card">
                <img src="img/equipment.jpeg" alt="Equipment">
                <div class="service-text">
                    <h3>Equipment</h3>
                    <p class="large-text">We supply and operate top-tier utility equipment, from trenchers to cable plows, and drills
                        ensuring efficiency in all underground installation projects. Our fleet is maintained to the highest standards.</p>
                </div>
            </div>
        </section>
    `;

  // Customer Feedback Section
  const customerFeedback = `
        <section id="customer-feedback">
            <h2 class="section-title">Customer Feedback</h2>
            <div class="feedback-container">
                <div class="feedback-card">
                    <h3>Fiber Optic Installation</h3>
                    <p class="stars">⭐⭐⭐⭐⭐</p>
                    <p>"WireKorp did an outstanding job installing fiber optic cables for our business. Their team was professional, fast, and the quality of work was exceptional!"</p>
                </div>
                <div class="feedback-card">
                    <h3>Pond Excavation</h3>
                    <p class="stars">⭐⭐⭐⭐⭐</p>
                    <p>"From planning to execution, WireKorp delivered an incredible pond excavation service. The final result exceeded our expectations. Highly recommended!"</p>
                </div>
                <div class="feedback-card">
                    <h3>Utility Mapping</h3>
                    <p class="stars">⭐⭐⭐⭐⭐</p>
                    <p>"Accurate mapping was crucial for our project, and WireKorp provided exceptional service. Their attention to detail and expertise ensured everything was redlined correctly."</p>
                </div>
            </div>
        </section>
    `;

  // Contact Us Section
  const contact = `
        <section id="contact">
            <h2 class="section-title">Contact Us</h2>
            <p class="contact-text"><strong>Address:</strong></p>
            <p class="contact-text">862 Monticello Rd, Eatonton, GA, 31024</p>
            <p class="contact-text"><strong>Phone:</strong> <a href="tel:9375320083">937-532-0083</a></p>
            <p class="contact-text"><strong>Email:</strong> <a href="mailto:WireKorpllc@gmail.com">WireKorpllc@gmail.com</a></p>
        </section>
    `;

  // Footer (Rights Reserved)
  const footer = `
        <footer>
            <p>&copy; 1998 WireKorp LLC. All rights reserved.</p>
        </footer>
    `;

  // Inject Components into #app
  app.innerHTML = header + hero + aboutUs + featuredServices + customerFeedback + contact + footer;
});
